# Mastermind VPS Toolkit

## Overview

This is a comprehensive terminal-based VPS management toolkit called "Mastermind." The project provides powerful shell scripts and Python tools for VPS management, proxy services, network optimization, and system administration on Ubuntu/Debian systems.

## System Architecture

### Terminal-Based Architecture
- **Core Management**: Bash-based menu system and service controls
- **Scripting Language**: Shell scripts with Python integration
- **Configuration**: File-based configuration management
- **Service Management**: systemd integration for service control
- **User Interface**: Interactive terminal menus and command-line tools

### VPS Toolkit Components
The project includes several Python-based network tools:
- **Proxy Services**: SOCKS5, HTTP, and WebSocket proxy implementations
- **Response Servers**: Custom HTTP response servers for multiple ports
- **QR Code Generation**: Dynamic QR code generation for connection configurations
- **Network Protocols**: Support for V2Ray, SSH ecosystem, TCP bypass, and BadVPN

## Key Components

### Database Schema
- **Users Table**: Basic user management with username/password authentication
- **Drizzle ORM**: Type-safe database operations with PostgreSQL dialect
- **Schema Validation**: Zod schemas for runtime type validation

### Authentication & Authorization
- **Session-based Authentication**: Using PostgreSQL for session storage
- **User Management**: Basic CRUD operations for user accounts
- **Memory Storage**: Fallback in-memory storage for development

### API Structure
- **Express Server**: RESTful API endpoints under `/api` prefix
- **Error Handling**: Centralized error handling middleware
- **Request Logging**: Comprehensive logging for API requests

### Frontend Components
- **shadcn/ui**: Comprehensive UI component library
- **Form Handling**: React Hook Form with Zod validation
- **Responsive Design**: Mobile-first design with Tailwind CSS
- **Dark Mode**: CSS variables-based theming system

## Data Flow

1. **Client Requests**: React frontend makes HTTP requests to Express backend
2. **API Processing**: Express routes handle business logic and database operations
3. **Database Operations**: Drizzle ORM manages PostgreSQL interactions
4. **Response Handling**: TanStack Query manages client-side caching and state
5. **UI Updates**: React components re-render based on state changes

## External Dependencies

### Database
- **Neon Database**: Serverless PostgreSQL hosting
- **Connection Pooling**: Built-in connection management

### UI Libraries
- **Radix UI**: Accessible, unstyled UI primitives
- **Tailwind CSS**: Utility-first CSS framework
- **Lucide Icons**: Icon library for React

### Development Tools
- **TypeScript**: Static type checking
- **ESLint**: Code linting and formatting
- **Vite**: Fast development server and build tool

### VPS Toolkit Dependencies
- **Python 3**: Runtime for proxy services and network tools
- **System Packages**: Various Linux utilities for network management
- **Service Management**: systemd integration for service management

## Deployment Strategy

### Development
- **Vite Dev Server**: Hot module replacement for frontend development
- **Express Server**: Backend API server with auto-restart
- **Database**: Development database connection via environment variables

### Production
- **Build Process**: Vite builds optimized frontend assets
- **Server Bundle**: esbuild creates server bundle for production
- **Static Serving**: Express serves built frontend assets
- **Environment Variables**: DATABASE_URL required for production

### VPS Deployment
- **Operating System**: Ubuntu 20.04+ or Debian 10+
- **System Requirements**: 1 vCPU, 512MB RAM minimum
- **Network Ports**: 22 (SSH), 80 (HTTP), 443 (HTTPS)
- **Service Management**: systemd services for various toolkit components

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes

✓ Removed all web UI components (React, Node.js, TypeScript)
✓ Converted to pure terminal-based VPS toolkit
✓ Updated documentation to reflect script-only structure
✓ Maintained comprehensive .gitignore file for security
✓ Updated README.md for terminal toolkit focus
✓ Kept MIT LICENSE file
✓ Updated DEPLOYMENT.md with script deployment instructions
✓ Completely redesigned menu.sh with modern UI/UX (v3.0.0)
✓ Enhanced color scheme with bright colors and modern design
✓ Added numbered menu options with visual icons
✓ Fixed arithmetic errors in progress bar calculations
✓ Improved system monitoring with real-time dashboards
✓ Added quick actions menu for common tasks
✓ Enhanced service status indicators with color coding
✓ Project ready for GitHub upload as VPS script toolkit
✓ Removed web UI components - pure terminal-based toolkit
✓ Fixed Python proxy dependencies and logging paths
✓ Verified all Python protocols working correctly
✓ Removed web UI components - pure terminal VPS toolkit
✓ Python proxy, QR generator, and core protocols functioning
✓ Ready for manual GitHub upload with provided access token
✓ Terminal toolkit fully functional and ready for deployment
✓ Fixed Python proxy and TCP bypass service configuration issues
✓ Resolved log directory creation and permissions problems  
✓ Updated systemd services to run with proper environment variables
✓ Fixed empty directory path error in first_run.sh and helpers.sh
✓ Fixed Python proxy AsyncIO event loop error with threading
✓ Completed V2Ray manager with VLESS/VMESS configuration support
✓ Added comprehensive Domain & SSL management system
✓ Enhanced service status detection and port monitoring
✓ Fixed all file duplication and syntax errors
✓ Completed all missing protocol management functions

## Changelog

- July 06, 2025: Complete UI/UX redesign of menu system (v3.0.0)
  - Modern colorful interface with numbered options
  - Enhanced system monitoring dashboards
  - Quick actions menu for common tasks
  - Fixed syntax errors and improved reliability
- July 05, 2025: Initial setup and complete project preparation for GitHub upload