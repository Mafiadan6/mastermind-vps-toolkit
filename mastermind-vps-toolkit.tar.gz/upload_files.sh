#!/bin/bash

# GitHub API Upload Script
TOKEN="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"
REPO="mafiadan6/mastermind-vps-toolkit"
API_URL="https://api.github.com/repos/$REPO/contents"

# Function to upload a file
upload_file() {
    local file_path="$1"
    local content=$(base64 -w 0 "$file_path")
    local message="Update $file_path - v3.0.0 with V2Ray fixes"
    
    echo "Uploading: $file_path"
    
    # Check if file exists
    local sha=$(curl -s -H "Authorization: token $TOKEN" \
        "$API_URL/$file_path" | jq -r '.sha // empty')
    
    local json_data
    if [ -n "$sha" ]; then
        # File exists, update it
        json_data=$(jq -n \
            --arg message "$message" \
            --arg content "$content" \
            --arg sha "$sha" \
            '{message: $message, content: $content, sha: $sha}')
    else
        # File doesn't exist, create it
        json_data=$(jq -n \
            --arg message "$message" \
            --arg content "$content" \
            '{message: $message, content: $content}')
    fi
    
    curl -s -X PUT -H "Authorization: token $TOKEN" \
        -H "Content-Type: application/json" \
        -d "$json_data" \
        "$API_URL/$file_path" > /dev/null
    
    if [ $? -eq 0 ]; then
        echo "✅ Successfully uploaded: $file_path"
    else
        echo "❌ Failed to upload: $file_path"
    fi
}

echo "🚀 Starting file upload to GitHub..."
echo "Repository: $REPO"
echo

# Upload core files
upload_file "README.md"
upload_file "LICENSE"
upload_file "install.sh"
upload_file "demo.sh"
upload_file "DEPLOYMENT.md"
upload_file "GITHUB_UPLOAD.md"
upload_file "PORT_MAPPING.md"
upload_file "replit.md"

# Upload core directory
upload_file "core/menu.sh"
upload_file "core/config.cfg"
upload_file "core/helpers.sh"
upload_file "core/first_run.sh"
upload_file "core/banner_setup.sh"
upload_file "core/service_ctl.sh"

# Upload protocols directory
upload_file "protocols/python_proxy.py"
upload_file "protocols/v2ray_manager.sh"
upload_file "protocols/ssh_suite.sh"
upload_file "protocols/tcp_bypass.sh"
upload_file "protocols/badvpn_setup.sh"
upload_file "protocols/proxy_manager.sh"
upload_file "protocols/squid_proxy.sh"

# Upload branding directory
upload_file "branding/qr_generator.py"
upload_file "branding/response_servers.py"
upload_file "branding/banner_generator.sh"

# Upload network directory
upload_file "network/bbr.sh"
upload_file "network/kernel_tuning.sh"
upload_file "network/udp_optimizer.sh"

# Upload security directory
upload_file "security/firewall_manager.sh"
upload_file "security/fail2ban_setup.sh"
upload_file "security/audit_tool.sh"

# Upload users directory
upload_file "users/user_manager.sh"

echo
echo "✅ Upload complete!"
echo "🌟 Repository: https://github.com/$REPO"