#!/bin/bash

# Mastermind VPS Toolkit - GitHub Upload Script
# Run this script to upload the toolkit to GitHub

set -e

echo "====================================="
echo "Mastermind VPS Toolkit GitHub Upload"
echo "====================================="

# GitHub credentials
GITHUB_USERNAME="mafiadan6"
GITHUB_TOKEN="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"
REPO_NAME="mastermind-vps-toolkit"

echo "Configuring Git..."
git config user.name "mafiadan6"
git config user.email "tyreakrobinson@gmail.com"

echo "Adding files to repository..."
git add .

echo "Creating commit..."
git commit -m "Mastermind VPS Toolkit v3.0.0 - All Issues Fixed

✓ Python Proxy AsyncIO error fixed
✓ V2Ray Manager completed with VLESS/VMESS support  
✓ Service status detection improved
✓ Menu layout enhanced with modern UI
✓ Domain & SSL management added
✓ Installation script optimized
✓ All Python protocols working correctly
✓ Ready for VPS deployment"

echo "Setting up remote repository..."
git remote add origin https://github.com/mafiadan6/mastermind-vps-toolkit.git

echo "Pushing to GitHub..."
git branch -M main
git push -u origin main

echo ""
echo "✅ Upload completed successfully!"
echo ""
echo "Your VPS toolkit is now available at:"
echo "https://github.com/mafiadan6/mastermind-vps-toolkit"
echo ""
echo "To install on a VPS, users can run:"
echo "curl -sSL https://raw.githubusercontent.com/mafiadan6/mastermind-vps-toolkit/main/install.sh | sudo bash"
echo ""