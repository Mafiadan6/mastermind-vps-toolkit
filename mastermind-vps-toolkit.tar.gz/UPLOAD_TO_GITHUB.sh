#!/bin/bash

# Mastermind VPS Toolkit - GitHub Upload Script
# This script will upload the complete project to your GitHub repository

echo "🚀 Uploading Mastermind VPS Toolkit to GitHub..."
echo

# Set Git configuration
echo "📝 Configuring Git..."
git config --global user.name "mafiadan6"
git config --global user.email "tyreakrobinson@gmail.com"

# Initialize repository
echo "🔧 Initializing Git repository..."
git init

# Add all files
echo "📁 Adding project files..."
git add .

# Create commit
echo "💾 Creating commit..."
git commit -m "🎯 Mastermind VPS Toolkit v3.0.0 - Complete UI/UX Redesign & V2Ray Fix

✨ Features:
- Modern colorful terminal interface with numbered menus
- Enhanced system monitoring with real-time progress bars
- Fixed all arithmetic errors and syntax issues
- Added Quick Actions menu for common tasks
- Professional GitHub-ready documentation
- Visual status indicators with color coding
- Responsive design that works on any terminal size

🔧 V2Ray Fixes:
- Added missing V2RAY_PORT configuration variable
- Implemented all required helper functions
- Fixed configuration paths and dependencies
- Added uuid-runtime for proper UUID generation
- Validated all script syntax

🚀 Ready for production deployment on Ubuntu/Debian VPS systems"

# Add remote repository
echo "🔗 Adding remote repository..."
git remote add origin https://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@github.com/mafiadan6/mastermind-vps-toolkit.git

# Push to GitHub
echo "⬆️ Pushing to GitHub..."
git push -u origin main

echo "✅ Upload complete!"
echo "🌟 Your repository is available at: https://github.com/mafiadan6/mastermind-vps-toolkit"
echo
echo "🎉 Project Summary:"
echo "   - Modern colorful menu system (v3.0.0)"
echo "   - Fixed V2Ray functionality"
echo "   - Complete VPS management toolkit"
echo "   - Ready for production use"